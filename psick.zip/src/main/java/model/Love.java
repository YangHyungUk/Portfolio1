package model;

public class Love {
	private int pno;
	private String id;
	private String l_del;
	
	public int getPno() {
		return pno;
	}
	public void setPno(int pno) {
		this.pno = pno;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getL_del() {
		return l_del;
	}
	public void setL_del(String l_del) {
		this.l_del = l_del;
	}
	
	
}
